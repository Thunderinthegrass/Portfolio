// function complexJsItemHeight() {
//   let complexItem = document.querySelectorAll('.complex-item');
//
//   complexItem.forEach((item, i) => {
//     let itemWidth = item.offsetWidth;
//     console.log(itemWidth);
//     item.style.height = `${itemWidth}px`;
//   });
// }
// complexJsItemHeight();
